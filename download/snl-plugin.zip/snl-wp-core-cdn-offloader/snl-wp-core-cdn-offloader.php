<?php
/*
Plugin Name: SnL WP Core CDN Offloader
Plugin URI:  https://wordpress-cdn.sticknologic.is-a.dev
Description: Offload WordPress core static assets (wp-includes and wp-admin) to https://wordpress-cdn.sticknologic.is-a.dev. Toggle ON/OFF, shows compatibility notice if CDN version differs. Maintained by STICKnoLOGIC.
Version:     1.0.0
Author:      STICKnoLOGIC
Author URI:  https://sticknologic.is-a.dev
License:     GPLv2 or later
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SnL_WP_Core_CDN_Offloader {
    private $cdn_url = 'https://wordpress-cdn.sticknologic.is-a.dev';
    private $option_enabled = 'snl_cdn_offloader_enabled';
    private $option_dismiss  = 'snl_cdn_offloader_notice_dismissed';
    private $issues_url = 'https://github.com/sticknologic/wordpress-cdn/issues';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'SnL_add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'SnL_register_settings' ) );
        add_action( 'admin_init', array( $this, 'SnL_handle_dismiss' ) );
        add_action( 'admin_init', array( $this, 'SnL_check_versions_and_maybe_warn' ) );

        if ( get_option( $this->option_enabled, 0 ) ) {
            add_filter( 'script_loader_src', array( $this, 'SnL_rewrite_asset_url' ), 10, 2 );
            add_filter( 'style_loader_src', array( $this, 'SnL_rewrite_asset_url' ), 10, 2 );
            add_filter( 'site_url', array( $this, 'SnL_filter_site_url' ), 10, 3 );
            add_filter( 'content_url', array( $this, 'SnL_filter_content_url' ), 10, 2 );
        }
    }

    public function SnL_add_settings_page() {
        add_options_page(
            'SnL CDN Offloader',
            'SnL CDN Offloader',
            'manage_options',
            'snl-cdn-offloader',
            array( $this, 'SnL_render_settings_page' )
        );
    }

    public function SnL_register_settings() {
        register_setting( 'snl_cdn_offloader_group', $this->option_enabled, array( 'type' => 'boolean', 'sanitize_callback' => 'absint', 'default' => 0 ) );
        register_setting( 'snl_cdn_offloader_group', $this->option_dismiss, array( 'type' => 'boolean', 'sanitize_callback' => 'absint', 'default' => 0 ) );
    }

    public function SnL_render_settings_page() {
        $enabled = (int) get_option( $this->option_enabled, 0 );
        $dismissed = (int) get_option( $this->option_dismiss, 0 );
        $local_version = $this->SnL_get_local_wp_version();
        $cdn_version = $this->SnL_fetch_cdn_version();
        ?>
        <div class="wrap">
            <h1>SnL WP Core CDN Offloader</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'snl_cdn_offloader_group' ); ?>
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row">Enable CDN Offloading</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo esc_attr( $this->option_enabled ); ?>" value="1" <?php checked( 1, $enabled ); ?> />
                                    Load wp-includes and wp-admin assets from <strong><?php echo esc_html( $this->cdn_url ); ?></strong>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">CDN Version</th>
                            <td>
                                <p><strong>Local WordPress:</strong> <?php echo esc_html( $local_version ); ?></p>
                                <p><strong>CDN WordPress:</strong> <?php echo esc_html( $cdn_version ? $cdn_version : 'Unavailable' ); ?></p>
                                <?php if ( $cdn_version && version_compare( $local_version, $cdn_version, '!=' ) ) : ?>
                                    <p style="color:#b77000;"><strong>Compatibility:</strong> Local and CDN versions do not match. Some assets may be incompatible.</p>
                                <?php elseif ( $cdn_version ) : ?>
                                    <p style="color:green;"><strong>Compatibility:</strong> Versions match.</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Dismissed Notice</th>
                            <td>
                                <p><?php echo $dismissed ? 'Compatibility notice currently dismissed.' : 'Compatibility notice not dismissed.'; ?></p>
                                <?php if ( $dismissed ) : ?>
                                    <a href="<?php echo esc_url( add_query_arg( 'snl_reset_dismiss', '1' ) ); ?>" class="button">Reset Dismissal</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <?php submit_button(); ?>
            </form>
            <hr/>
            <h2>Credits</h2>
            <p>Maintained by <a href="https://sticknologic.is-a.dev" target="_blank" rel="noopener">STICKnoLOGIC</a></p>
            <p>💖 <a href="https://github.com/sponsors/STICKnoLOGIC" target="_blank" rel="noopener">Sponsor STICKnoLOGIC on GitHub</a></p>
            <p>Report CDN issues: <a href="<?php echo esc_url( $this->issues_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $this->issues_url ); ?></a></p>
        </div>
        <?php
    }

    public function SnL_handle_dismiss() {
        if ( isset( $_GET['snl_dismiss'] ) && '1' === $_GET['snl_dismiss'] && current_user_can( 'manage_options' ) ) {
            update_option( $this->option_dismiss, 1 );
            wp_safe_redirect( remove_query_arg( 'snl_dismiss' ) );
            exit;
        }
        if ( isset( $_GET['snl_reset_dismiss'] ) && '1' === $_GET['snl_reset_dismiss'] && current_user_can( 'manage_options' ) ) {
            delete_option( $this->option_dismiss );
            wp_safe_redirect( remove_query_arg( 'snl_reset_dismiss' ) );
            exit;
        }
    }

    public function SnL_check_versions_and_maybe_warn() {
        if ( get_option( $this->option_dismiss, 0 ) ) return;
        $local_version = $this->SnL_get_local_wp_version();
        $cdn_version   = $this->SnL_fetch_cdn_version();
        if ( $cdn_version && version_compare( $local_version, $cdn_version, '!=' ) ) {
            add_action( 'admin_notices', array( $this, 'SnL_admin_compat_notice' ) );
        }
    }

    public function SnL_admin_compat_notice() {
        $local_version = $this->SnL_get_local_wp_version();
        $cdn_version   = $this->SnL_fetch_cdn_version();
        $dismiss_url   = add_query_arg( 'snl_dismiss', '1' );
        ?>
        <div class="notice notice-warning is-dismissible">
            <p><strong>SnL WP Core CDN Offloader:</strong> Compatibility issue detected: your WordPress version (<code><?php echo esc_html( $local_version ); ?></code>) does not match the CDN version (<code><?php echo esc_html( $cdn_version ); ?></code>). Please update WordPress or wait for the CDN to update, otherwise some assets may not run as expected.</p>
            <p>If you believe this is an error, please report it on GitHub: <a href="<?php echo esc_url( $this->issues_url ); ?>" target="_blank" rel="noopener">Open an issue</a>.</p>
            <p><a href="<?php echo esc_url( $dismiss_url ); ?>" class="button">Dismiss</a></p>
        </div>
        <?php
    }

    private function SnL_get_local_wp_version() {
        global $wp_version;
        return isset( $wp_version ) ? $wp_version : 'unknown';
    }

    private function SnL_fetch_cdn_version() {
        $url = trailingslashit( $this->cdn_url ) . 'wp-version.json';
        $transient_key = 'snl_cdn_version_cache';
        $cached = get_transient( $transient_key );
        if ( $cached ) return $cached;
        $response = wp_remote_get( $url, array( 'timeout' => 5 ) );
        if ( is_wp_error( $response ) ) return false;
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( is_array( $data ) && ! empty( $data['version'] ) ) {
            $version = sanitize_text_field( $data['version'] );
            set_transient( $transient_key, $version, 10 * MINUTE_IN_SECONDS );
            return $version;
        }
        return false;
    }

    public function SnL_rewrite_asset_url( $src, $handle = '' ) {
        if ( empty( $src ) ) return $src;
        $path = wp_parse_url( $src, PHP_URL_PATH );
        if ( ! $path ) return $src;
        if ( strpos( $path, '/wp-includes/' ) === false && strpos( $path, '/wp-admin/' ) === false) return $src;
        if ( preg_match( '/\.(php|txt)(\?|$)/i', $path ) ) return $src;
        return rtrim( $this->cdn_url, '/' ) . $path;
    }

    public function SnL_filter_site_url( $url, $path, $scheme ) { return $url; }
    public function SnL_filter_content_url( $url, $path ) { return $url; }
}

new SnL_WP_Core_CDN_Offloader();
