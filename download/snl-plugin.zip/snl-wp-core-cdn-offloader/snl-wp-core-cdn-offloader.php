<?php
/*
Plugin Name: SnL WP Core CDN Offloader
Plugin URI:  https://wordpress-cdn.sticknologic.is-a.dev
Description: Offload WordPress core static assets (wp-includes and wp-admin) to a version-aware CDN. Maintained by STICKnoLOGIC.
Version:     1.1.0
Author:      STICKnoLOGIC
Author URI:  https://sticknologic.is-a.dev
License:     GPLv2 or later
*/

if (!defined("ABSPATH")) {
    exit();
}

// Admin settings
require_once plugin_dir_path(__FILE__) . "includes/admin-page.php";

class SnL_WP_Core_CDN_Connector
{
    private $cdn = "https://wordpress-cdn.sticknologic.is-a.dev/";
    private $option_enabled = "snl_cdn_offloader_enabled";

    public function __construct()
    {
        $local = $this->get_local_version();
        $cdn = $this->get_cdn_version();

        if (!$cdn || $cdn === $local) {
            $this->cdn .= $cdn;
        } else if ($this->is_local_version_hosted($local)) {
            $this->cdn .= $local;
        }else{
        $this->cdn .= $cdn;
        }
        
        if (get_option($this->option_enabled, 0)) {
            add_filter("script_loader_src", [$this, "rewrite_core_urls"], 999, 1);
            add_filter("style_loader_src", [$this, "rewrite_core_urls"], 999, 1);
            add_filter("includes_url", [$this, "rewrite_generic_url"], 999, 1);
            add_filter("wp_print_importmap", [$this, "rewrite_importmap"], 999, 1);
        }

        add_action('admin_notices', [$this, 'show_version_notice']);
    }

    private function get_local_version()
    {
        global $wp_version;
        return isset( $wp_version ) ? $wp_version : 'unknown';
    }

    private function get_cdn_version()
    {
        $transient_key = 'snl_cdn_version';
        $cached = get_transient($transient_key);
        if ($cached !== false) {
            return $cached;
        }

        $response = wp_remote_get($this->cdn . '/wp-version.json', ['timeout' => 5]);
        if (is_wp_error($response)) {
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if (!empty($data['version'])) {
            set_transient($transient_key, $data['version'], HOUR_IN_SECONDS);
            return $data['version'];
        }

        return null;
    }

    private function is_local_version_hosted($local_version)
    {
        $url = trailingslashit($this->cdn) . $local_version . '/wp-version.json';
        $response = wp_remote_head($url, ['timeout' => 5]);
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }


    private function is_php_path($path)
    {
        return (bool) preg_match('/\.php(?:$|[?#])/i', $path);
    }

    private function extract_path($url)
    {
        $path = $url;
        if (preg_match("#^https?:#i", $url) || preg_match("#^//#", $url)) {
            $tmp = strpos($url, "//") === 0 ? "https:" . $url : $url;
            $parts = wp_parse_url($tmp);
            if (empty($parts["path"])) {
                return null;
            }
            $path = $parts["path"];
            if (!empty($parts["query"])) {
                $path .= "?" . $parts["query"];
            }
            if (!empty($parts["fragment"])) {
                $path .= "#" . $parts["fragment"];
            }
        }
        return $path;
    }

    private function replace_with_cdn($url)
    {
        if (!is_string($url) || $url === "") {
            return $url;
        }

        $path = $this->extract_path($url);
        if (!$path || strpos($path, '/wp-content/') !== false || $this->is_php_path($path)) {
            return $url;
        }

        if (
            strpos($path, '/wp-includes/') === false &&
            strpos($path, '/wp-admin/') === false
        ) {
            return $url;
        }

        return $this->cdn . $path;
    }

    public function rewrite_core_urls($src)
    {
        return $this->replace_with_cdn($src);
    }

    public function rewrite_generic_url($url)
    {
        return $this->replace_with_cdn($url);
    }

    public function rewrite_importmap($importmap)
    {
        if (empty($importmap)) {
            return $importmap;
        }

        $is_string = is_string($importmap);
        $str = $is_string ? $importmap : wp_json_encode($importmap);

        $str = preg_replace_callback(
            '#(?:"|\')((?:https?:\/\/|\/\/|\/)(?:wp-includes|wp-admin)\/[^"\']+)(?:"|\')#i',
            function ($m) {
                $orig = $m[1];
                $new = $this->replace_with_cdn($orig);
                $quote = $m[0][0];
                return $quote . $new . $quote;
            },
            $str
        );

        if ($is_string) {
            return $str;
        }

        $decoded = json_decode($str, true);
        return $decoded !== null ? $decoded : $importmap;
    }

    public function show_version_notice()
    {
        $local = $this->get_local_version();
        $cdn = $this->get_cdn_version();
        if ($cdn && $cdn !== $local) {
            echo '<div class="notice notice-warning"><p><strong>SnL CDN Offloader:</strong> CDN version (' . esc_html($cdn) . ') does not match local WordPress version (' . esc_html($local) . ').</p></div>';
        }
    }
}

add_action("init", function () {
    new SnL_WP_Core_CDN_Connector();
}, 20);
