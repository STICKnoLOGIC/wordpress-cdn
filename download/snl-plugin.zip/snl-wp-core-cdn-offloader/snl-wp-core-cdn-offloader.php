<?php
/*
Plugin Name: SnL WP Core CDN Offloader
Plugin URI:  https://wordpress-cdn.sticknologic.is-a.dev
Description: Offload WordPress core static assets (wp-includes and wp-admin) to https://wordpress-cdn.sticknologic.is-a.dev. Toggle ON/OFF, shows compatibility notice if CDN version differs. Maintained by STICKnoLOGIC.
Version:     1.0.2
Author:      STICKnoLOGIC
Author URI:  https://sticknologic.is-a.dev
License:     GPLv2 or later
*/

if (!defined("ABSPATH")) {
    exit();
}

// Admin settings
require_once plugin_dir_path(__FILE__) . "includes/admin-page.php";

class SnL_WP_Core_CDN_Connector
{
    private $cdn = "https://wordpress-cdn.sticknologic.is-a.dev";
    private $option_enabled = "snl_cdn_offloader_enabled";

    public function __construct()
    {
        if (get_option($this->option_enabled, 0)) {
            // Enqueued assets
            add_filter(
                "script_loader_src",
                [$this, "rewrite_core_urls"],
                999,
                1
            );
            add_filter(
                "style_loader_src",
                [$this, "rewrite_core_urls"],
                999,
                1
            );

            // Core URL getters
            add_filter("includes_url", [$this, "rewrite_generic_url"], 999, 1);
            if (!$this->should_rewrite()) {
                add_filter("admin_url", [$this, "rewrite_generic_url"], 999, 1);
            }

            // Importmap / inline map best-effort
            add_filter(
                "wp_print_importmap",
                [$this, "rewrite_importmap"],
                999,
                1
            );
        }
    }

    private function is_php_path($path)
    {
        return (bool) preg_match('/\.php(?:$|[?#])/i', $path);
    }

    private function should_rewrite()
    {
        if (is_admin()) {
            return false;
        } // admin pages
        if (defined("DOING_AJAX") && DOING_AJAX) {
            return false;
        }
        if (defined("DOING_CRON") && DOING_CRON) {
            return false;
        }
        if (defined("REST_REQUEST") && REST_REQUEST) {
            return false;
        }
        if (defined("WP_CLI") && WP_CLI) {
            return false;
        }
        if (is_user_logged_in()) {
            return false;
        } // logged-in users
        $uri = $_SERVER["REQUEST_URI"] ?? "";
        if (stripos($uri, "wp-login.php") !== false) {
            return false;
        } // login page or POST

        return true;
    }
    /**
     * Replace URL only when it points to /wp-includes/ or /wp-admin/
     * Accepts absolute, protocol-relative and relative URLs.
     * Does NOT modify /wp-content/.
     */
    private function replace_with_cdn($url)
    {
        if (!is_string($url) || $url === "") {
            return $url;
        }

        $url = trim($url);

        // Extract path portion
        $path = $url;

        // If absolute or protocol-relative, normalize so wp_parse_url can extract path
        if (preg_match("#^https?:#i", $url) || preg_match("#^//#", $url)) {
            $tmp = $url;
            if (strpos($tmp, "//") === 0) {
                $tmp = "https:" . $tmp;
            }
            $parts = wp_parse_url($tmp);
            if (empty($parts["path"])) {
                return $url;
            }
            $path = $parts["path"];
            if (!empty($parts["query"])) {
                $path .= "?" . $parts["query"];
            }
            if (!empty($parts["fragment"])) {
                $path .= "#" . $parts["fragment"];
            }
        }

        // Only target wp-includes and wp-admin
        if (
            strpos($path, "/wp-includes/") === false &&
            strpos($path, "/wp-admin/") === false
        ) {
            return $url;
        }

        // Do NOT rewrite wp-content (explicit safety)
        if (strpos($path, "/wp-content/") !== false) {
            return $url;
        }

        // Skip PHP endpoints
        if ($this->is_php_path($path)) {
            return $url;
        }

        $cdn = rtrim($this->cdn, "/");
        return $cdn . $path;
    }

    public function rewrite_core_urls($src)
    {
        return $this->replace_with_cdn($src);
    }

    public function rewrite_generic_url($url)
    {
        return $this->replace_with_cdn($url);
    }

    public function rewrite_importmap($importmap)
    {
        if (empty($importmap)) {
            return $importmap;
        }

        $is_string = is_string($importmap);
        $str = $is_string ? $importmap : wp_json_encode($importmap);

        // Replace absolute, protocol-relative and relative occurrences for wp-includes and wp-admin only
        $str = preg_replace_callback(
            '#(?:"|\')((?:https?:\/\/|\/\/|\/)(?:wp-includes|wp-admin)\/[^"\']+)(?:"|\')#i',
            function ($m) {
                $orig = $m[1];
                $new = $this->replace_with_cdn($orig);
                // preserve surrounding quotes
                $quote = $m[0][0];
                return $quote . $new . $quote;
            },
            $str
        );

        if ($is_string) {
            return $str;
        }

        $decoded = json_decode($str, true);
        if ($decoded !== null) {
            return $decoded;
        }
        return $importmap;
    }
}

add_action(
    "init",
    function () {
        // instantiate your class or add filters that call is_user_logged_in()
        new SnL_WP_Core_CDN_Connector();
    },
    20
);
