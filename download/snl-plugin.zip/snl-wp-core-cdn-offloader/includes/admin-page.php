<?php
if (!defined('ABSPATH')) exit;
define('SnL_CDN_URL','https://wordpress-cdn.sticknologic.is-a.dev');
define('SnL_OPTION_ENABLED','snl_cdn_offloader_enabled');
define('SnL_OPTION_DISMISS','snl_cdn_offloader_notice_dismissed');
define('SnL_ISSUE_URL','https://github.com/sticknologic/wordpress-cdn/issues');

function SnL_add_settings_page() {
    add_options_page(
        'SnL CDN Offloader',
        'SnL CDN Offloader',
        'manage_options',
        'snl-cdn-offloader',
        'SnL_render_settings_page'
    );
}

function SnL_register_settings() {
    register_setting( 'snl_cdn_offloader_group', SnL_OPTION_ENABLED, array( 'type' => 'boolean', 'sanitize_callback' => 'absint', 'default' => 0 ) );
    register_setting( 'snl_cdn_offloader_group', SnL_OPTION_DISMISS, array( 'type' => 'boolean', 'sanitize_callback' => 'absint', 'default' => 0 ) );
}

function SnL_render_settings_page() {
    $enabled = (int) get_option( SnL_OPTION_ENABLED, 0 );
    $dismissed = (int) get_option( SnL_OPTION_DISMISS, 0 );
    $local_version = SnL_get_local_wp_version();
    $cdn_version = SnL_fetch_cdn_version();
    ?>
    <div class="wrap">
        <h1>SnL WP Core CDN Offloader</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'snl_cdn_offloader_group' ); ?>
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row">Enable CDN Offloading</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr( SnL_OPTION_ENABLED ); ?>" value="1" <?php checked( 1, $enabled ); ?> />
                                Load wp-includes and wp-admin assets from <strong><?php echo esc_html( SnL_CDN_URL ); ?></strong>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">CDN Version</th>
                        <td>
                            <p><strong>Local WordPress:</strong> <?php echo esc_html( $local_version ); ?></p>
                            <p><strong>CDN WordPress:</strong> <?php echo esc_html( $cdn_version ? $cdn_version : 'Unavailable' ); ?></p>
                            <?php if ( $cdn_version && version_compare( $local_version, $cdn_version, '!=' ) ) : ?>
                                <p style="color:#b77000;"><strong>Compatibility:</strong> Local and CDN versions do not match. Some assets may be incompatible.</p>
                            <?php elseif ( $cdn_version ) : ?>
                                <p style="color:green;"><strong>Compatibility:</strong> Versions match.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Dismissed Notice</th>
                        <td>
                            <p><?php echo $dismissed ? 'Compatibility notice currently dismissed.' : 'Compatibility notice not dismissed.'; ?></p>
                            <?php if ( $dismissed ) : ?>
                                <a href="<?php echo esc_url( add_query_arg( 'snl_reset_dismiss', '1' ) ); ?>" class="button">Reset Dismissal</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php submit_button(); ?>
        </form>
        <hr/>
        <h2>Credits</h2>
        <p>Maintained by <a href="https://sticknologic.is-a.dev" target="_blank" rel="noopener">STICKnoLOGIC</a></p>
        <p>💖 <a href="https://github.com/sponsors/STICKnoLOGIC" target="_blank" rel="noopener">Sponsor STICKnoLOGIC on GitHub</a></p>
        <p>Report CDN issues: <a href="<?php echo esc_url( SnL_ISSUE_URL ); ?>" target="_blank" rel="noopener"><?php echo esc_html( SnL_ISSUE_URL ); ?></a></p>
    </div>
    <?php
}

function SnL_handle_dismiss() {
    if ( isset( $_GET['snl_dismiss'] ) && '1' === $_GET['snl_dismiss'] && current_user_can( 'manage_options' ) ) {
        update_option( SnL_OPTION_DISMISS, 1 );
        wp_safe_redirect( remove_query_arg( 'snl_dismiss' ) );
        exit;
    }
    if ( isset( $_GET['snl_reset_dismiss'] ) && '1' === $_GET['snl_reset_dismiss'] && current_user_can( 'manage_options' ) ) {
        delete_option( SnL_OPTION_DISMISS );
        wp_safe_redirect( remove_query_arg( 'snl_reset_dismiss' ) );
        exit;
    }
}

function SnL_check_versions_and_maybe_warn() {
    if ( get_option( SnL_OPTION_DISMISS, 0 ) ) return;
    $local_version = SnL_get_local_wp_version();
    $cdn_version   = SnL_fetch_cdn_version();
    if ( $cdn_version && version_compare( $local_version, $cdn_version, '!=' ) ) {
        add_action( 'admin_notices', array( $this, 'SnL_admin_compat_notice' ) );
    }
}

function SnL_admin_compat_notice() {
    $local_version = SnL_get_local_wp_version();
    $cdn_version   = SnL_fetch_cdn_version();
    $dismiss_url   = add_query_arg( 'snl_dismiss', '1' );
    ?>
    <div class="notice notice-warning is-dismissible">
        <p><strong>SnL WP Core CDN Offloader:</strong> Compatibility issue detected: your WordPress version (<code><?php echo esc_html( $local_version ); ?></code>) does not match the CDN version (<code><?php echo esc_html( $cdn_version ); ?></code>). Please update WordPress or wait for the CDN to update, otherwise some assets may not run as expected.</p>
        <p>If you believe this is an error, please report it on GitHub: <a href="<?php echo esc_url( SnL_ISSUE_URL ); ?>" target="_blank" rel="noopener">Open an issue</a>.</p>
        <p><a href="<?php echo esc_url( $dismiss_url ); ?>" class="button">Dismiss</a></p>
    </div>
    <?php
}

function SnL_get_local_wp_version() {
    global $wp_version;
    return isset( $wp_version ) ? $wp_version : 'unknown';
}

function SnL_fetch_cdn_version() {
    $url = trailingslashit( SnL_CDN_URL ) . 'wp-version.json';
    $transient_key = 'snl_cdn_version_cache';
    $cached = get_transient( $transient_key );
    if ( $cached ) return $cached;
    $response = wp_remote_get( $url, array( 'timeout' => 5 ) );
    if ( is_wp_error( $response ) ) return false;
    $data = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( is_array( $data ) && ! empty( $data['version'] ) ) {
        $version = sanitize_text_field( $data['version'] );
        set_transient( $transient_key, $version, 10 * MINUTE_IN_SECONDS );
        return $version;
    }
    return false;
}


add_action( 'admin_menu', 'SnL_add_settings_page' );
add_action( 'admin_init', 'SnL_register_settings' );
add_action( 'admin_init', 'SnL_handle_dismiss' );
add_action( 'admin_init', 'SnL_check_versions_and_maybe_warn' );